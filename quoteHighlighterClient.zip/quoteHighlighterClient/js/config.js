Config = {
    'host' : 'https://www.quotsy.net/'
}